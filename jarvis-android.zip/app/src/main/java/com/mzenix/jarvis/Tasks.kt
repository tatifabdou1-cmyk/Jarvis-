package com.mzenix.jarvis

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Task(val id: Long, val text: String, val done: Boolean, val due: Long)

object TaskStore {
    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun all(ctx: Context): MutableList<Task> {
        val a = JSONArray(sp(ctx).getString("tasks", "[]"))
        val out = mutableListOf<Task>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Task(o.getLong("id"), o.getString("text"), o.getBoolean("done"), o.optLong("due", 0L)))
        }
        return out
    }

    fun pending(ctx: Context): List<Task> = all(ctx).filter { !it.done }

    private fun save(ctx: Context, list: List<Task>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("text", it.text).put("done", it.done).put("due", it.due))
        }
        sp(ctx).edit().putString("tasks", a.toString()).apply()
    }

    fun add(ctx: Context, text: String, due: Long = 0L): Task {
        val list = all(ctx)
        list.removeAll { it.done }
        val t = Task(System.currentTimeMillis(), text.trim(), false, due)
        list.add(t)
        save(ctx, list)
        return t
    }

    fun completeById(ctx: Context, id: Long) {
        val list = all(ctx)
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            list[idx] = list[idx].copy(done = true)
            save(ctx, list)
            Reminders.cancel(ctx, id)
        }
    }

    fun complete(ctx: Context, query: String): Task? {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return null
        val list = all(ctx)
        val idx = list.indexOfFirst {
            val t = it.text.lowercase(Locale.ROOT)
            !it.done && (t.contains(q) || q.contains(t))
        }
        if (idx < 0) return null
        val done = list[idx].copy(done = true)
        list[idx] = done
        save(ctx, list)
        Reminders.cancel(ctx, done.id)
        return done
    }

    fun clearAll(ctx: Context) {
        all(ctx).forEach { Reminders.cancel(ctx, it.id) }
        save(ctx, emptyList())
    }
}

object Reminders {
    private fun code(id: Long): Int = (id and 0x7fffffffL).toInt()

    private fun pending(ctx: Context, id: Long, text: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .setAction(ReminderReceiver.ACT_REMIND)
            .putExtra("id", id)
            .putExtra("text", text)
        return PendingIntent.getBroadcast(
            ctx, code(id), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun schedule(ctx: Context, id: Long, text: String, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx, id, text))
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx, id, ""))
    }

    fun scheduleNudge(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val i = Intent(ctx, ReminderReceiver::class.java).setAction(ReminderReceiver.ACT_NUDGE)
        val pi = PendingIntent.getBroadcast(
            ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + AlarmManager.INTERVAL_HOUR,
            3 * AlarmManager.INTERVAL_HOUR,
            pi
        )
    }
}

object Notifs {
    const val CH_SERVICE = "jarvis_service"
    const val CH_REMIND = "jarvis_remind"

    fun ensure(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_SERVICE, "Standby", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_REMIND, "Reminders", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    fun show(ctx: Context, id: Int, title: String, text: String) {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, CH_REMIND)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}
