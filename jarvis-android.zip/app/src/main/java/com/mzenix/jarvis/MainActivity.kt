package com.mzenix.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    companion object {
        const val MODEL = "claude-haiku-5-5"
        const val API_URL = "https://api.anthropic.com/v1/messages"
    }

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var prefs: SharedPreferences

    private val langs = listOf("en-US", "ar-SA", "fr-FR")
    private val yesPhrases = listOf("Yes, sir.", "نعم سيدي", "Oui, monsieur.")
    private var langIndex = 0
    private val history = mutableListOf<Pair<String, String>>()

    private val wakeRegex = Regex("^(jarvis|جارفيس|جارفس)[,،.!\\s]*", RegexOption.IGNORE_CASE)
    private val remindRegex = Regex("remind me in (\\d+)\\s*(second|minute|hour)s?\\s*(?:to|that)?\\s*(.*)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        logView = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        val keyInput = findViewById<EditText>(R.id.keyInput)
        val saveBtn = findViewById<Button>(R.id.saveKey)
        val langBtn = findViewById<Button>(R.id.langBtn)
        val micBtn = findViewById<Button>(R.id.micBtn)

        tts = TextToSpeech(this, this)

        saveBtn.setOnClickListener {
            val k = keyInput.text.toString().trim()
            if (k.isNotEmpty()) {
                prefs.edit().putString("key", k).apply()
                keyInput.setText("")
                Toast.makeText(this, "Key saved", Toast.LENGTH_SHORT).show()
            }
        }

        langBtn.text = langs[langIndex]
        langBtn.setOnClickListener {
            langIndex = (langIndex + 1) % langs.size
            langBtn.text = langs[langIndex]
            if (ttsReady) tts.language = Locale.forLanguageTag(langs[langIndex])
        }

        micBtn.setOnClickListener { onMic() }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
        append("Jarvis: At your service, sir. Tap the button and speak.")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts.language = Locale.forLanguageTag(langs[langIndex])
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) {
                    if (utteranceId == "listen") runOnUiThread { startListening() }
                }
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "listen") runOnUiThread { startListening() }
                }
            })
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            append("Jarvis: I need microphone access to hear you, sir.")
        }
    }

    private fun onMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (ttsReady) {
            tts.stop()
            speak(yesPhrases[langIndex], true)
        } else {
            startListening()
        }
    }

    private fun speak(text: String, listenAfter: Boolean) {
        if (!ttsReady) {
            if (listenAfter) startListening()
            return
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, if (listenAfter) "listen" else "say")
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply("Speech recognition is not available on this device, sir.")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { append("(listening...)") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { append("(I didn't catch that, sir.)") }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) append("(I didn't catch that, sir.)") else handle(text)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langs[langIndex])
        }
        r.startListening(i)
    }

    // ---------- Command handling ----------

    private fun has(l: String, vararg words: String) = words.any { l.contains(it) }

    private fun handle(raw: String) {
        append("You: $raw")
        val t = raw.trim().replaceFirst(wakeRegex, "").trim()
        val l = t.lowercase(Locale.ROOT)
        val rememberPrefixes = listOf("remember that ", "remember ", "تذكر أن ", "تذكر ", "احفظ ")

        when {
            l.isEmpty() -> reply("Yes, sir?")

            has(l, "what do you remember", "what do you know about me", "شنو تتذكر", "ماذا تتذكر") -> {
                val m = memory()
                if (m.isEmpty()) reply("I have nothing on file yet, sir.")
                else reply("Here is what I remember, sir. " + m.joinToString(". "))
            }

            has(l, "forget everything", "انسى كل شي", "انسى كل شيء") -> {
                saveMemory(emptyList())
                reply("Memory cleared, sir.")
            }

            rememberPrefixes.any { l.startsWith(it) } -> {
                val p = rememberPrefixes.first { l.startsWith(it) }
                val fact = t.drop(p.length).trim()
                if (fact.isEmpty()) {
                    reply("Remember what, sir?")
                } else {
                    val m = memory()
                    m.add(fact)
                    saveMemory(m)
                    reply("Noted, sir.")
                }
            }

            has(l, "battery", "بطارية", "شحن", "batterie") -> reply(batteryText())

            has(l, "what time", "the time", "كم الساعة", "الساعة كم", "quelle heure") ->
                reply("It is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}, sir.")

            remindRegex.containsMatchIn(l) -> setTimer(l)

            l.startsWith("open ") -> openThing(t.drop(5))
            l.startsWith("launch ") -> openThing(t.drop(7))
            l.startsWith("افتح ") -> openThing(t.drop(5))
            l.startsWith("شغل ") -> openThing(t.drop(4))

            else -> askAi(t)
        }
    }

    private fun reply(text: String) {
        append("Jarvis: $text")
        speak(text, false)
    }

    private fun append(s: String) {
        logView.append("$s\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun batteryText(): String {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val state = if (bm.isCharging) "charging" else "not charging"
        return "Battery is at $level percent, sir, and $state."
    }

    private fun setTimer(l: String) {
        val m = remindRegex.find(l) ?: return
        val n = m.groupValues[1].toIntOrNull() ?: 0
        if (n <= 0) {
            reply("I couldn't understand the duration, sir.")
            return
        }
        val unit = m.groupValues[2]
        val secs = when (unit) {
            "hour" -> n * 3600
            "minute" -> n * 60
            else -> n
        }.coerceIn(1, 86400)
        val what = m.groupValues[3].ifBlank { "Reminder" }
        try {
            startActivity(
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, what)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            reply("Very good, sir. I will remind you in $n ${unit}s.")
        } catch (e: Exception) {
            reply("I couldn't set the timer, sir.")
        }
    }

    private fun openThing(nameRaw: String) {
        val name = nameRaw.trim()
        if (name.isEmpty()) {
            reply("Open what, sir?")
            return
        }
        if (name.startsWith("http") || (name.contains(".") && !name.contains(" "))) {
            val url = if (name.startsWith("http")) name else "https://$name"
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                reply("Opening it now, sir.")
            } catch (e: Exception) {
                reply("I couldn't open that link, sir.")
            }
            return
        }
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(name.lowercase(Locale.ROOT))
        }
        val launch = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (match != null && launch != null) {
            reply("Opening ${match.loadLabel(pm)}, sir.")
            startActivity(launch)
        } else {
            reply("I couldn't find $name, sir.")
        }
    }

    // ---------- Memory ----------

    private fun memory(): MutableList<String> {
        val a = JSONArray(prefs.getString("memory", "[]"))
        return MutableList(a.length()) { a.getString(it) }
    }

    private fun saveMemory(list: List<String>) {
        prefs.edit().putString("memory", JSONArray(list).toString()).apply()
    }

    // ---------- AI fallback ----------

    private fun askAi(userText: String) {
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) {
            reply("I didn't understand that command, sir. Add an API key and I can handle open conversation.")
            return
        }
        val mem = memory()
        val system = "You are J.A.R.V.I.S., a personal voice assistant on the user's Android phone, " +
            "modeled on the AI from Iron Man. Address the user as 'sir'. Be calm, polite, with light dry wit. " +
            "Your replies are spoken aloud, so use one or two short sentences and no markdown. " +
            "Reply in the language the user speaks. You cannot control the phone beyond the built-in " +
            "commands (open apps or links, battery, time, timers, memory); if asked for something else, say so. " +
            "Things you know about the user: " + (if (mem.isEmpty()) "nothing yet." else mem.joinToString("; "))
        val snapshot = history.takeLast(6).toList()
        append("(thinking...)")
        Thread {
            val answer = try {
                callApi(key, system, snapshot, userText)
            } catch (e: Exception) {
                "I couldn't reach the service, sir."
            }
            runOnUiThread {
                history.add("user" to userText)
                history.add("assistant" to answer)
                while (history.size > 12) history.removeAt(0)
                reply(answer)
            }
        }.start()
    }

    private fun callApi(key: String, system: String, past: List<Pair<String, String>>, userText: String): String {
        val msgs = JSONArray()
        past.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        msgs.put(JSONObject().put("role", "user").put("content", userText))
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 300)
            .put("system", system)
            .put("messages", msgs)

        val conn = URL(API_URL).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        if (code !in 200..299) return "The service returned error $code, sir."
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        return JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text").trim()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
