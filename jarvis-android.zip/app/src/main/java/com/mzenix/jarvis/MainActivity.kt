package com.mzenix.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), JarvisUi {

    companion object {
        @Volatile
        var visible = false
    }

    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var wakeSwitch: Switch
    private lateinit var prefs: Prefs
    private var hinted = false

    private val wakeListener = CompoundButton.OnCheckedChangeListener { _, checked ->
        prefs.wakeEnabled = checked
        JarvisService.instance?.refreshWake()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyWakeFlags(intent)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        orb = findViewById(R.id.orb)
        status = findViewById(R.id.status)
        logView = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        wakeSwitch = findViewById(R.id.wakeSwitch)

        findViewById<Button>(R.id.settingsBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.tasksBtn).setOnClickListener { showTasks() }
        findViewById<Button>(R.id.micBtn).setOnClickListener { onMic() }

        if (!hasMic()) requestPerms()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyWakeFlags(intent)
    }

    private fun applyWakeFlags(i: Intent?) {
        if (i?.getBooleanExtra("wake", false) == true && Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        JarvisService.ui = this
        logView.text = ""
        JarvisService.logBuffer.forEach { logView.append(it + "\n\n") }
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        onState(JarvisService.state)

        wakeSwitch.setOnCheckedChangeListener(null)
        wakeSwitch.isChecked = prefs.wakeEnabled
        wakeSwitch.setOnCheckedChangeListener(wakeListener)

        if (hasMic()) startJarvis()
        if (!hinted && !Settings.canDrawOverlays(this)) {
            hinted = true
            onLog("Tip: so I can pop up while the app is closed, open Settings and allow \"Display over other apps\".")
        }
    }

    override fun onPause() {
        visible = false
        if (JarvisService.ui === this) JarvisService.ui = null
        super.onPause()
    }

    // ---------------- UI callbacks from the service ----------------

    override fun onLog(line: String) {
        logView.append(line + "\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onState(state: Int) {
        orb.state = state
        status.text = when (state) {
            JarvisService.STATE_WAKE -> "Waiting for the wake word..."
            JarvisService.STATE_LISTEN -> "Listening..."
            JarvisService.STATE_THINK -> "Thinking..."
            JarvisService.STATE_SPEAK -> "Speaking..."
            else -> "Standing by"
        }
    }

    // ---------------- Permissions and service ----------------

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasMic()) startJarvis() else onLog("I need microphone access to hear you.")
    }

    private fun startJarvis() {
        try {
            startForegroundService(Intent(this, JarvisService::class.java))
        } catch (e: Exception) {
            onLog("I couldn't start my background service.")
        }
    }

    private fun onMic() {
        if (!hasMic()) {
            requestPerms()
            return
        }
        val s = JarvisService.instance
        if (s != null) {
            s.manualListen()
        } else {
            startJarvis()
            Handler(Looper.getMainLooper()).postDelayed({ JarvisService.instance?.manualListen() }, 900)
        }
    }

    // ---------------- Tasks dialog ----------------

    private fun showTasks() {
        val list = TaskStore.pending(this)
        val fmt = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
        val items = list.map {
            it.text + if (it.due > 0) "   (" + fmt.format(Date(it.due)) + ")" else ""
        }.toTypedArray()
        val b = AlertDialog.Builder(this).setTitle("Tasks (tap one to mark it done)")
        if (items.isEmpty()) {
            b.setMessage("No pending tasks.")
        } else {
            b.setItems(items) { _, i ->
                TaskStore.completeById(this, list[i].id)
                Toast.makeText(this, "Done", Toast.LENGTH_SHORT).show()
            }
        }
        b.setPositiveButton("Add") { _, _ -> addTaskDialog() }
        b.setNegativeButton("Close", null)
        b.show()
    }

    private fun addTaskDialog() {
        val input = EditText(this)
        input.hint = "New task"
        AlertDialog.Builder(this)
            .setTitle("Add a task")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) TaskStore.add(this, t)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
