package com.mzenix.jarvis

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.mzenix.jarvis.STOP"
        const val STATE_IDLE = 0
        const val STATE_WAKE = 1
        const val STATE_LISTEN = 2
        const val STATE_THINK = 3
        const val STATE_SPEAK = 4
        const val MODEL = "claude-haiku-5-5"
        const val API_URL = "https://api.anthropic.com/v1/messages"
        const val NOTIF_ID = 77

        @Volatile
        var instance: JarvisService? = null
        var ui: JarvisUi? = null
        var state = STATE_IDLE
        val logBuffer = ArrayList<String>()

        fun log(line: String) {
            logBuffer.add(line)
            while (logBuffer.size > 60) logBuffer.removeAt(0)
            ui?.onLog(line)
        }

        fun setState(s: Int) {
            state = s
            ui?.onState(s)
        }
    }

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: Pair<String, () -> Unit>? = null
    private val callbacks = HashMap<String, () -> Unit>()
    private var utt = 0
    private var recognizer: SpeechRecognizer? = null
    private var token = 0
    private var wakeActive = false
    private val history = mutableListOf<Pair<String, String>>()

    private val c: String get() = prefs.callName

    // ---------------- Service lifecycle ----------------

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        Notifs.ensure(this)
        Reminders.scheduleNudge(this)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startInForeground()
        } catch (e: Exception) {
            log("Jarvis: I can't run in the background right now. Open the app and try again.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (prefs.wakeEnabled && !wakeActive && state == STATE_IDLE) startWake()
        return START_STICKY
    }

    override fun onDestroy() {
        wakeActive = false
        destroyRecognizer()
        tts?.shutdown()
        instance = null
        setState(STATE_IDLE)
        super.onDestroy()
    }

    private fun startInForeground() {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, Notifs.CH_SERVICE)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis is on standby")
            .setContentText("Say \"${prefs.wakeWord}\" to wake me")
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------- Text to speech ----------------

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            log("Jarvis: My voice engine failed to start.")
            return
        }
        ttsReady = true
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finishUtterance(utteranceId) }
            override fun onError(utteranceId: String?) { finishUtterance(utteranceId) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                if (utteranceId != null) handler.post { callbacks.remove(utteranceId) }
            }
        })
        pendingSpeech?.let { p ->
            pendingSpeech = null
            speak(p.first, p.second)
        }
    }

    private fun finishUtterance(id: String?) {
        if (id == null) return
        handler.post { callbacks.remove(id)?.invoke() }
    }

    private fun applyVoice(t: TextToSpeech, text: String) {
        val arabic = text.any { it in '\u0600'..'\u06FF' }
        val loc = when {
            arabic -> Locale("ar")
            prefs.lang == "fr-FR" -> Locale.FRANCE
            else -> Locale.UK
        }
        t.setLanguage(loc)
        val preferred = listOf("rjs", "gbd", "iom", "iol", "tpd", "smtm", "male")
        val voices = t.voices ?: emptySet()
        val pick = voices.firstOrNull { v ->
            val n = v.name.lowercase(Locale.ROOT)
            v.locale.language == loc.language && !n.contains("female") && preferred.any { n.contains(it) }
        }
        if (pick != null) t.setVoice(pick)
        t.setPitch(prefs.pitch)
        t.setSpeechRate(prefs.rate)
    }

    private fun speak(text: String, onDone: () -> Unit = { resumeWake() }) {
        val t = tts
        if (t == null || !ttsReady) {
            pendingSpeech = text to onDone
            return
        }
        applyVoice(t, text)
        val id = "u${++utt}"
        callbacks[id] = onDone
        setState(STATE_SPEAK)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun reply(text: String, then: () -> Unit = { resumeWake() }) {
        log("Jarvis: $text")
        speak(text, then)
    }

    /** Called from outside (reminders, settings test) to speak a line. */
    fun say(text: String) {
        wakeActive = false
        destroyRecognizer()
        reply(text)
    }

    // ---------------- Speech recognition ----------------

    private fun destroyRecognizer() {
        token++
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
    }

    private fun startRecognizer(lang: String, forWake: Boolean) {
        destroyRecognizer()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("Jarvis: Speech recognition is not available on this phone.")
            wakeActive = false
            setState(STATE_IDLE)
            return
        }
        val my = token
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                if (my != token) return
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    log("Jarvis: I need microphone permission.")
                    wakeActive = false
                    setState(STATE_IDLE)
                    return
                }
                if (forWake) {
                    val busy = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                        error == SpeechRecognizer.ERROR_CLIENT
                    restartWake(if (busy) 1500L else 250L)
                } else {
                    log("(I didn't catch that, $c.)")
                    resumeWake()
                }
            }

            override fun onResults(results: Bundle?) {
                if (my != token) return
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                if (forWake) onWakeResult(list) else {
                    val text = list.firstOrNull()
                    if (text.isNullOrBlank()) {
                        log("(I didn't catch that, $c.)")
                        resumeWake()
                    } else {
                        process(text)
                    }
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        r.startListening(i)
    }

    // ---------------- Wake word loop ----------------

    private fun wakeVariants(): List<String> {
        val w = prefs.wakeWord.trim().lowercase(Locale.ROOT).ifEmpty { "jarvis" }
        return if (w == "jarvis") {
            listOf("jarvis", "jarves", "jarvus", "جارفيس", "جارفس", "جارفز")
        } else {
            listOf(w)
        }
    }

    private fun startWake() {
        if (!prefs.wakeEnabled) {
            wakeActive = false
            setState(STATE_IDLE)
            return
        }
        wakeActive = true
        setState(STATE_WAKE)
        startRecognizer("en-US", true)
    }

    private fun restartWake(delay: Long) {
        handler.postDelayed({
            if (wakeActive && state == STATE_WAKE) startRecognizer("en-US", true)
        }, delay)
    }

    private fun resumeWake() {
        if (!prefs.wakeEnabled) {
            wakeActive = false
            setState(STATE_IDLE)
            return
        }
        setState(STATE_WAKE)
        handler.postDelayed({ if (state == STATE_WAKE) startWake() }, 500)
    }

    fun refreshWake() {
        if (state == STATE_IDLE || state == STATE_WAKE) {
            destroyRecognizer()
            wakeActive = false
            if (prefs.wakeEnabled) startWake() else setState(STATE_IDLE)
        }
    }

    private fun onWakeResult(alts: List<String>) {
        val variants = wakeVariants()
        val hit = alts.firstOrNull { a ->
            val l = a.lowercase(Locale.ROOT)
            variants.any { l.contains(it) }
        }
        if (hit == null) {
            restartWake(100)
            return
        }
        wakeActive = false
        destroyRecognizer()
        bringUi()
        val after = stripWake(hit).trim()
        if (after.length >= 3) process(hit) else sayAckThenListen()
    }

    private fun bringUi() {
        if (!prefs.popup || MainActivity.visible) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("wake", true)
            )
        } catch (e: Exception) {
        }
    }

    /** Called by the mic button. */
    fun manualListen() {
        wakeActive = false
        destroyRecognizer()
        tts?.stop()
        callbacks.clear()
        sayAckThenListen()
    }

    private fun ack(): String {
        val call = c
        return when (prefs.lang) {
            "ar-DZ" -> "نعم يا " + (if (call.equals("sir", true)) "سيدي" else call)
            "fr-FR" -> "Oui, " + (if (call.equals("sir", true)) "monsieur" else call) + "."
            else -> "Yes, $call."
        }
    }

    private fun sayAckThenListen() {
        val a = ack()
        log("Jarvis: $a")
        speak(a) { startCommandListen() }
    }

    private fun startCommandListen() {
        setState(STATE_LISTEN)
        startRecognizer(prefs.lang, false)
    }

    // ---------------- Command handling ----------------

    private fun stripWake(raw: String): String {
        val alt = wakeVariants().joinToString("|") { Regex.escape(it) }
        return raw.trim().replaceFirst(
            Regex("^(?:hey\\s+|okay\\s+|ok\\s+)?(?:$alt)[,،.!\\s]*", RegexOption.IGNORE_CASE), ""
        )
    }

    private fun process(raw: String) {
        log("You: $raw")
        setState(STATE_THINK)
        handle(raw)
    }

    private fun has(l: String, vararg words: String) = words.any { l.contains(it) }

    private val politeRegex = Regex("^(?:(?:can|could|would|will) you (?:please )?|please )", RegexOption.IGNORE_CASE)
    private val remindRegex = Regex("^remind me (?:in (\\d+)\\s*(second|minute|min|hour)s?|at (\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?)\\s*(?:to|that|about)?\\s*(.*)$")
    private val ytRegex1 = Regex("^(?:search|find|look)\\s+(?:in |on )?(?:the )?youtube\\s*(.*)$")
    private val ytRegex2 = Regex("^(?:search|find|look)\\s+(?:for\\s+)?(.+?)\\s+(?:in|on)\\s+youtube$")
    private val ytRegexAr = Regex("^ابحث\\s+(?:في|على)\\s+(?:ال)?يوتيوب\\s*(?:عن)?\\s*(.*)$")
    private val playRegex = Regex("^play\\s+(.+?)(?:\\s+on youtube)?$")
    private val googleRegex = Regex("^(?:google|search(?: google)?(?: for)?|look up)\\s+(.+)$")
    private val googleRegexAr = Regex("^ابحث\\s+(?:عن\\s+)?(.+)$")
    private val mapsRegex = Regex("^(?:navigate to|directions to|take me to)\\s+(.+)$")
    private val openRegex = Regex("^(?:open|launch|start)\\s+(.+)$")
    private val openRegexAr = Regex("^(?:افتح|شغل)\\s+(.+)$")
    private val addTaskRegex = Regex("^(?:add (?:a )?task(?: to)?|new task|add to my tasks|remind me to)\\s+(.+)$")
    private val addTaskRegexAr = Regex("^(?:أضف|اضف|سجل)\\s+مهمة\\s+(.+)$")
    private val doneRegex = Regex("^(?:done with|finished|complete|mark)\\s+(?:task\\s+)?(.+?)(?:\\s+as done)?$")
    private val doneRegexAr = Regex("^(?:خلصت|انتهيت من)\\s+(.+)$")
    private val callMeRegex = Regex("^(?:call me|address me as|from now on call me)\\s+(.+)$")
    private val callMeRegexAr = Regex("^(?:ناديني|نادني)\\s+(.+)$")
    private val rememberPrefixes = listOf("remember that ", "remember ", "تذكر أن ", "تذكر ", "احفظ ")

    private fun handle(raw: String) {
        var t = stripWake(raw).trim()
        t = t.replace(politeRegex, "").trim()
        val l = t.lowercase(Locale.ROOT).trimEnd('.', '!', '?', '؟')
        val call = c

        if (l.isEmpty()) { reply("Yes, $call?"); return }
        if (l in listOf("stop", "cancel", "never mind", "nevermind", "الغي", "إلغاء")) {
            reply("Very well, $call."); return
        }
        if (l in listOf("thanks", "thank you", "شكرا", "شكراً")) {
            reply("At your service, $call."); return
        }

        // ----- personalization and memory -----
        callMeRegex.find(l)?.let { m -> setCallName(m.groupValues[1]); return }
        callMeRegexAr.find(l)?.let { m -> setCallName(m.groupValues[1]); return }

        if (has(l, "what do you remember", "what do you know about me", "شنو تتذكر", "ماذا تتذكر")) {
            val m = prefs.memory()
            if (m.isEmpty()) reply("I have nothing on file yet, $call.")
            else reply("Here is what I remember, $call. " + m.joinToString(". "))
            return
        }
        if (has(l, "forget everything", "انسى كل شي", "انسى كل شيء")) {
            prefs.saveMemory(emptyList())
            reply("Memory cleared, $call."); return
        }
        val rp = rememberPrefixes.firstOrNull { l.startsWith(it) }
        if (rp != null) {
            val fact = t.drop(rp.length).trim()
            if (fact.isEmpty()) {
                reply("Remember what, $call?")
            } else {
                val m = prefs.memory()
                m.add(fact)
                prefs.saveMemory(m)
                reply("Noted, $call.")
            }
            return
        }

        // ----- tasks and reminders -----
        remindRegex.find(l)?.let { m -> setReminder(m); return }
        addTaskRegex.find(l)?.let { m -> addTask(m.groupValues[1]); return }
        addTaskRegexAr.find(l)?.let { m -> addTask(m.groupValues[1]); return }
        if (has(l, "my tasks", "task list", "to do list", "to-do list", "what do i have to do", "مهامي", "ما هي مهامي")) {
            readTasks(); return
        }
        doneRegex.find(l)?.let { m -> completeTask(m.groupValues[1]); return }
        doneRegexAr.find(l)?.let { m -> completeTask(m.groupValues[1]); return }
        if (has(l, "clear my tasks", "delete all tasks", "امسح المهام")) {
            TaskStore.clearAll(this)
            reply("All tasks cleared, $call."); return
        }

        // ----- phone info -----
        if (has(l, "battery", "بطارية", "شحن", "batterie")) { reply(batteryText()); return }
        if (has(l, "what time", "the time", "كم الساعة", "الساعة كم", "quelle heure")) {
            reply("It is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}, $call."); return
        }
        if (has(l, "what day", "the date", "today's date", "اي يوم", "أي يوم")) {
            reply("Today is ${SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())}, $call."); return
        }

        // ----- actions: YouTube, search, maps, open -----
        ytRegex1.find(l)?.let { m -> doYoutube(m.groupValues[1]); return }
        ytRegex2.find(l)?.let { m -> doYoutube(m.groupValues[1]); return }
        ytRegexAr.find(l)?.let { m -> doYoutube(m.groupValues[1]); return }
        playRegex.find(l)?.let { m -> doYoutube(m.groupValues[1]); return }
        mapsRegex.find(l)?.let { m ->
            val q = m.groupValues[1]
            reply(if (maps(q)) "On it, $call. Opening the map for $q." else "I couldn't open maps, $call.")
            return
        }
        googleRegex.find(l)?.let { m ->
            val q = m.groupValues[1]
            reply(if (googleSearch(q)) "On it, $call. Searching for $q." else "I couldn't open the browser, $call.")
            return
        }
        googleRegexAr.find(l)?.let { m ->
            val q = m.groupValues[1]
            reply(if (googleSearch(q)) "حاضر، أبحث عن $q" else "ما قدرت أفتح المتصفح")
            return
        }
        openRegex.find(l)?.let { m -> doOpen(m.groupValues[1]); return }
        openRegexAr.find(l)?.let { m -> doOpen(m.groupValues[1]); return }

        // ----- everything else goes to the AI -----
        askAi(t)
    }

    private fun setCallName(nameRaw: String) {
        val name = nameRaw.trim().replaceFirstChar { it.uppercase() }
        if (name.isEmpty()) { reply("Call you what, $c?"); return }
        prefs.callName = name
        reply("Very well, $name.")
    }

    private fun batteryText(): String {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = if (bm.isCharging) "charging" else "not charging"
        return "Battery is at $level percent, $c, and $st."
    }

    // ----- tasks -----

    private fun setReminder(m: MatchResult) {
        val now = System.currentTimeMillis()
        val due: Long
        if (m.groupValues[1].isNotEmpty()) {
            val n = m.groupValues[1].toLongOrNull() ?: 0L
            if (n <= 0L) { reply("I couldn't understand the duration, $c."); return }
            val ms = when (m.groupValues[2]) {
                "hour" -> n * 3600000L
                "second" -> n * 1000L
                else -> n * 60000L
            }
            due = now + ms
        } else {
            var h = m.groupValues[3].toIntOrNull() ?: 0
            val min = (m.groupValues[4].ifEmpty { "0" }).toIntOrNull() ?: 0
            val ap = m.groupValues[5]
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            if (h > 23 || min > 59) { reply("That time doesn't look right, $c."); return }
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, h)
            cal.set(Calendar.MINUTE, min)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_MONTH, 1)
            due = cal.timeInMillis
        }
        val what = m.groupValues[6].ifBlank { "your reminder" }
        val task = TaskStore.add(this, what, due)
        Reminders.schedule(this, task.id, what, due)
        val whenText = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(due))
        reply("Very good, $c. I will remind you at $whenText.")
    }

    private fun addTask(text: String) {
        val what = text.trim()
        if (what.isEmpty()) { reply("Add what, $c?"); return }
        TaskStore.add(this, what)
        reply("Added to your tasks, $c.")
    }

    private fun readTasks() {
        val p = TaskStore.pending(this)
        if (p.isEmpty()) {
            reply("You have no pending tasks, $c.")
        } else {
            reply("You have ${p.size} pending, $c. " + p.joinToString(". ") { it.text })
        }
    }

    private fun completeTask(q: String) {
        val t = TaskStore.complete(this, q)
        if (t != null) reply("Marked as done, $c: ${t.text}.")
        else reply("I couldn't find a task like that, $c.")
    }

    // ----- phone actions -----

    private fun go(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    private fun openUrl(url: String): Boolean {
        val u = if (url.startsWith("http")) url else "https://$url"
        return go(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    }

    private fun parseYt(rest: String): Pair<String, Boolean> {
        var q = rest.trim()
        var channel = false
        val ch = Regex("^(?:for |about |on )?(?:the )?(?:channel|chanel)(?: of| for| named| called)?\\s+", RegexOption.IGNORE_CASE)
        if (ch.containsMatchIn(q)) {
            channel = true
            q = q.replace(ch, "")
        }
        q = q.replace(Regex("^(?:for|about|on|عن)\\s+", RegexOption.IGNORE_CASE), "").trim()
        if (q.endsWith(" channel")) {
            channel = true
            q = q.removeSuffix(" channel").trim()
        }
        return q to channel
    }

    private fun youtubeSearch(q: String, channel: Boolean): Boolean {
        var url = "https://www.youtube.com/results?search_query=" + Uri.encode(q)
        if (channel) url += "&sp=EgIQAg%3D%3D"
        val uri = Uri.parse(url)
        return go(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube")) ||
            go(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun doYoutube(rest: String) {
        val (q, channel) = parseYt(rest)
        if (q.isBlank()) { reply("Search for what, $c?"); return }
        val ok = youtubeSearch(q, channel)
        reply(
            if (ok) "On it, $c. Searching YouTube for $q."
            else "I couldn't open YouTube, $c."
        )
    }

    private fun googleSearch(q: String): Boolean =
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))

    private fun maps(q: String): Boolean =
        go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))

    private fun openApp(name: String): String? {
        val q = name.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return null
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(q)
        } ?: return null
        val li = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return null
        return if (go(li)) match.loadLabel(pm).toString() else null
    }

    private fun doOpen(nameRaw: String) {
        val name = nameRaw.trim()
        if (name.isEmpty()) { reply("Open what, $c?"); return }
        if (name.startsWith("http") || (name.contains(".") && !name.contains(" "))) {
            reply(if (openUrl(name)) "Opening it now, $c." else "I couldn't open that link, $c.")
            return
        }
        val label = openApp(name)
        if (label != null) reply("Opening $label, $c.") else reply("I couldn't find $name, $c.")
    }

    // ---------------- AI ----------------

    private fun buildSystemPrompt(): String {
        val mem = prefs.memory()
        val now = SimpleDateFormat("EEEE, MMMM d, yyyy h:mm a", Locale.ENGLISH).format(Date())
        return "You are J.A.R.V.I.S., the personal voice assistant of the user, running on his Android phone, " +
            "modeled on the AI from Iron Man. Address the user as \"${prefs.callName}\". Calm, polite, dry wit. " +
            "Your replies are spoken aloud: at most two short sentences, no markdown, no emojis. " +
            "Reply in the language the user speaks. " +
            "Respond with ONLY a JSON object: {\"say\":\"<spoken reply>\",\"actions\":[...]}. " +
            "Allowed actions: " +
            "{\"type\":\"youtube_search\",\"query\":\"...\",\"channel\":true or false}, " +
            "{\"type\":\"google_search\",\"query\":\"...\"}, " +
            "{\"type\":\"open_app\",\"name\":\"...\"}, " +
            "{\"type\":\"open_url\",\"url\":\"...\"}, " +
            "{\"type\":\"maps\",\"query\":\"...\"}, " +
            "{\"type\":\"add_task\",\"text\":\"...\"}, " +
            "{\"type\":\"remember\",\"text\":\"...\"}. " +
            "When the user asks you to do something, include the matching action and make \"say\" a short confirmation " +
            "that you are on it. For plain conversation use an empty actions list. " +
            "You cannot do anything outside these actions; if asked, say so honestly. " +
            "Current date and time: $now. " +
            (if (prefs.about.isNotBlank()) "About the user and how he wants you to behave: ${prefs.about}. " else "") +
            "Things you remember about the user: " + (if (mem.isEmpty()) "nothing yet." else mem.joinToString("; "))
    }

    private fun askAi(userText: String) {
        val key = prefs.apiKey
        if (key.isBlank()) {
            reply("I don't know that command yet, $c. Add an API key in Settings and I can handle anything you ask.")
            return
        }
        val system = buildSystemPrompt()
        val snapshot = history.takeLast(6).toList()
        setState(STATE_THINK)
        Thread {
            var result: String? = null
            var error: String? = null
            try {
                result = callApi(key, system, snapshot, userText)
            } catch (e: Exception) {
                error = e.message ?: "error"
            }
            handler.post { onAiResult(userText, result, error) }
        }.start()
    }

    private fun onAiResult(userText: String, raw: String?, error: String?) {
        if (raw == null) {
            when {
                error != null && error.startsWith("HTTP 401") ->
                    reply("My API key seems to be invalid, $c.")
                error != null && error.startsWith("HTTP") ->
                    reply("The service returned an error, $c. $error.")
                else -> reply("I couldn't reach my servers, $c.")
            }
            return
        }
        var say: String = raw
        var actions: JSONArray? = null
        try {
            val s = raw.indexOf('{')
            val e = raw.lastIndexOf('}')
            if (s >= 0 && e > s) {
                val o = JSONObject(raw.substring(s, e + 1))
                say = o.optString("say", raw)
                actions = o.optJSONArray("actions")
            }
        } catch (ex: Exception) {
            say = raw
        }
        actions?.let { arr ->
            for (i in 0 until arr.length()) {
                try { runAction(arr.getJSONObject(i)) } catch (ex: Exception) { }
            }
        }
        history.add("user" to userText)
        history.add("assistant" to say)
        while (history.size > 12) history.removeAt(0)
        reply(say)
    }

    private fun runAction(a: JSONObject) {
        when (a.optString("type")) {
            "youtube_search" -> youtubeSearch(a.optString("query"), a.optBoolean("channel", false))
            "google_search" -> googleSearch(a.optString("query"))
            "open_app" -> openApp(a.optString("name"))
            "open_url" -> openUrl(a.optString("url"))
            "maps" -> maps(a.optString("query"))
            "add_task" -> TaskStore.add(this, a.optString("text"))
            "remember" -> {
                val m = prefs.memory()
                m.add(a.optString("text"))
                prefs.saveMemory(m)
            }
        }
    }

    private fun callApi(key: String, system: String, past: List<Pair<String, String>>, userText: String): String {
        val msgs = JSONArray()
        past.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        msgs.put(JSONObject().put("role", "user").put("content", userText))
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 400)
            .put("system", system)
            .put("messages", msgs)

        val conn = URL(API_URL).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        return JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text").trim()
    }
}
