package com.mzenix.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

class OrbView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    // 0 idle, 1 waiting for wake word, 2 listening, 3 thinking, 4 speaking
    var state: Int = 0

    private var phase = 0f
    private val yellow = Color.parseColor("#FFC107")
    private val d = resources.displayMetrics.density

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = yellow; alpha = 90; strokeWidth = 2f * d
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = yellow; strokeWidth = 6f * d; strokeCap = Paint.Cap.ROUND
    }
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = yellow; alpha = 140; strokeWidth = 3f * d
        pathEffect = DashPathEffect(floatArrayOf(10f * d, 14f * d), 0f)
    }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = yellow }
    private val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#0A0A0A") }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rect = RectF()

    private val animator = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 4000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val r = min(w, h) / 2f
        glow.shader = RadialGradient(
            w / 2f, h / 2f, r,
            intArrayOf(Color.argb(110, 255, 193, 7), Color.argb(0, 255, 193, 7)),
            floatArrayOf(0.35f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.9f
        val k = when (state) { 2 -> 2; 3 -> 3; 4 -> 2; else -> 1 }
        val amp = when (state) { 4 -> 0.10f; 2 -> 0.07f; else -> 0.035f }
        val pulse = 1f + amp * sin(phase * k)

        canvas.drawCircle(cx, cy, r * pulse, glow)
        canvas.drawCircle(cx, cy, r * 0.95f, ring)

        val ang = Math.toDegrees((phase * k).toDouble()).toFloat()
        val ra = r * 0.8f
        rect.set(cx - ra, cy - ra, cx + ra, cy + ra)
        canvas.save()
        canvas.rotate(ang, cx, cy)
        canvas.drawArc(rect, 0f, 70f, false, arc)
        canvas.drawArc(rect, 120f, 70f, false, arc)
        canvas.drawArc(rect, 240f, 70f, false, arc)
        canvas.restore()

        canvas.save()
        canvas.rotate(-ang, cx, cy)
        canvas.drawCircle(cx, cy, r * 0.62f, dash)
        canvas.restore()

        canvas.drawCircle(cx, cy, r * 0.36f * pulse, core)
        canvas.drawCircle(cx, cy, r * 0.24f * pulse, hole)
        canvas.drawCircle(cx, cy, r * 0.13f * pulse, core)
    }
}
