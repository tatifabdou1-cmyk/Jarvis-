package com.mzenix.jarvis

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private val langs = listOf("en-US", "ar-DZ", "fr-FR")
    private var langIndex = 0
    private lateinit var prefs: Prefs
    private lateinit var callName: EditText
    private lateinit var wakeWord: EditText
    private lateinit var about: EditText
    private lateinit var apiKey: EditText
    private lateinit var pitchBar: SeekBar
    private lateinit var rateBar: SeekBar
    private lateinit var langBtn: Button
    private lateinit var wakeSwitch: Switch
    private lateinit var popupSwitch: Switch
    private lateinit var overlayStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = Prefs(this)

        callName = findViewById(R.id.callName)
        wakeWord = findViewById(R.id.wakeWord)
        about = findViewById(R.id.about)
        apiKey = findViewById(R.id.apiKey)
        pitchBar = findViewById(R.id.pitchBar)
        rateBar = findViewById(R.id.rateBar)
        langBtn = findViewById(R.id.langBtn)
        wakeSwitch = findViewById(R.id.wakeSwitch)
        popupSwitch = findViewById(R.id.popupSwitch)
        overlayStatus = findViewById(R.id.overlayStatus)

        callName.setText(prefs.callName)
        wakeWord.setText(prefs.wakeWord)
        about.setText(prefs.about)
        pitchBar.progress = ((prefs.pitch - 0.5f) * 100f).toInt().coerceIn(0, 100)
        rateBar.progress = ((prefs.rate - 0.6f) * 100f).toInt().coerceIn(0, 100)
        langIndex = langs.indexOf(prefs.lang).coerceAtLeast(0)
        langBtn.text = "Speech language: " + langs[langIndex]
        wakeSwitch.isChecked = prefs.wakeEnabled
        popupSwitch.isChecked = prefs.popup

        langBtn.setOnClickListener {
            langIndex = (langIndex + 1) % langs.size
            langBtn.text = "Speech language: " + langs[langIndex]
        }

        findViewById<Button>(R.id.overlayBtn).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        findViewById<Button>(R.id.batteryBtn).setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        findViewById<Button>(R.id.testBtn).setOnClickListener {
            saveAll()
            val s = JarvisService.instance
            if (s == null) {
                Toast.makeText(this, "Open the main screen first so I can start.", Toast.LENGTH_SHORT).show()
            } else {
                s.say("Good evening, ${prefs.callName}. All systems are operational.")
            }
        }
        findViewById<Button>(R.id.saveBtn).setOnClickListener {
            saveAll()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        val ok = Settings.canDrawOverlays(this)
        overlayStatus.text =
            if (ok) "Display over other apps: allowed" else "Display over other apps: NOT allowed (needed to pop up while the app is closed)"
    }

    private fun saveAll() {
        prefs.callName = callName.text.toString().trim().ifEmpty { "sir" }
        prefs.wakeWord = wakeWord.text.toString().trim().lowercase().ifEmpty { "jarvis" }
        prefs.about = about.text.toString().trim()
        val k = apiKey.text.toString().trim()
        if (k.isNotEmpty()) prefs.apiKey = k
        prefs.pitch = 0.5f + pitchBar.progress / 100f
        prefs.rate = 0.6f + rateBar.progress / 100f
        prefs.lang = langs[langIndex]
        prefs.wakeEnabled = wakeSwitch.isChecked
        prefs.popup = popupSwitch.isChecked
        JarvisService.instance?.refreshWake()
    }
}
