package com.mzenix.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        const val ACT_REMIND = "com.mzenix.jarvis.REMIND"
        const val ACT_NUDGE = "com.mzenix.jarvis.NUDGE"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        Notifs.ensure(ctx)
        val prefs = Prefs(ctx)
        when (intent.action) {
            ACT_REMIND -> {
                val text = intent.getStringExtra("text") ?: "Reminder"
                val id = intent.getLongExtra("id", 0L)
                Notifs.show(ctx, (id and 0x7fffffffL).toInt(), "Reminder", text)
                JarvisService.instance?.say("${prefs.callName}, a reminder: $text")
            }
            ACT_NUDGE -> {
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val pending = TaskStore.pending(ctx)
                if (hour in 9..21 && pending.isNotEmpty()) {
                    Notifs.show(
                        ctx, 2, "Pending tasks",
                        "You have ${pending.size} pending: " + pending.take(3).joinToString(", ") { it.text }
                    )
                }
            }
        }
    }
}
