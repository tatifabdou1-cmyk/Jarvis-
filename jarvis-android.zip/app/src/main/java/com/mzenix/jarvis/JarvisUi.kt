package com.mzenix.jarvis

interface JarvisUi {
    fun onLog(line: String)
    fun onState(state: Int)
}
