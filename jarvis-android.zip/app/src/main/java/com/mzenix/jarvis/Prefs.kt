package com.mzenix.jarvis

import android.content.Context
import org.json.JSONArray

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var callName: String
        get() = sp.getString("call", "sir") ?: "sir"
        set(v) { sp.edit().putString("call", v).apply() }

    var wakeWord: String
        get() = sp.getString("wake", "jarvis") ?: "jarvis"
        set(v) { sp.edit().putString("wake", v).apply() }

    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) { sp.edit().putString("key", v).apply() }

    var about: String
        get() = sp.getString("about", "") ?: ""
        set(v) { sp.edit().putString("about", v).apply() }

    var lang: String
        get() = sp.getString("lang", "en-US") ?: "en-US"
        set(v) { sp.edit().putString("lang", v).apply() }

    var pitch: Float
        get() = sp.getFloat("pitch", 0.8f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }

    var rate: Float
        get() = sp.getFloat("rate", 0.95f)
        set(v) { sp.edit().putFloat("rate", v).apply() }

    var wakeEnabled: Boolean
        get() = sp.getBoolean("wakeEnabled", true)
        set(v) { sp.edit().putBoolean("wakeEnabled", v).apply() }

    var popup: Boolean
        get() = sp.getBoolean("popup", true)
        set(v) { sp.edit().putBoolean("popup", v).apply() }

    fun memory(): MutableList<String> {
        val a = JSONArray(sp.getString("memory", "[]"))
        return MutableList(a.length()) { a.getString(it) }
    }

    fun saveMemory(list: List<String>) {
        sp.edit().putString("memory", JSONArray(list).toString()).apply()
    }
}
